// Acts as config
app.service('api_url', function(){
    return {
        url:"http://local33.samaiapp.com/api"
    }
});